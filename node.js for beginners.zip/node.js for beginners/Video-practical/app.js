var http = require('http');
var fs = require('fs');
http.createServer(
    function(request, response)
    {
        
        response.writeHead(200,{'Content-Type':'video/mp4'});
        var rs = fs.createReadStream('video.mp4');
        rs.pipe(response);
    }).listen(7000);
console.log('server was live at http://127.0.0.1:7000');
