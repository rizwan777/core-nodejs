

const Joi = require('joi');
const express = require('express');
const app = express();
app.use(express.json());


const courses=[
    {id :1  , name: 'bond1', address: 'Ahmedabad'},
    {id :2  , name: 'bond2', address: 'Delhi'},
    {id :3  , name: 'bond3', address:'Mumbai'},
    {id :4  , name: 'bond4', address:'Vadodra'},
    {id :5  , name: 'bond5', address:'Anand'}
];

app.get('/',(req,res)=>
{
    res.send('Hello World...this was use of Nodemon with Express');
});

//Set environment by of PORT
const port = process.env.PORT || 8080;

app.listen(port,()=>console.log(`server was live now on ${port}...`));


app.get('/api/courses',(req,res)=>
{
    const schema ={
        name:Joi.string().min(3).required()
    };
    const result =Joi.validate(req.body, schema);
   
    res.send(courses);
});

app.get('/api/courses/:id',(req,res)=>
{
    const data =courses.find(c=>c.id === parseInt(req.params.id) );
    if(!data) res.status(404).send('Given Id was not in Database...!!');
    res.send(data);
});
app.post('/api/courses',(req,res)=>
{
    const data ={
        id: courses.length + 1,
        Name : req.body .name,
        address: req.body.address
    }
    courses.push(data);
    res.send(data);

})

// app.get('/api/courses/:id/:address',()=>
// {
//     const data=courses.find((c=>c.id === parseInt(req.params.id)) &&(c=>c.address === req.params.address));
//     if(!data)
//         {
//             res.status(404).status('ID and Address was not in Database');
//         }
//     res.send(data);
// });

// app.get('/api/courses/:name',(req,res)=>
// {
//     const data = courses.find(c=>c.name === req.params.name);
//     if(!data) res.status(404).send("Given Name was not in Database...");
//     res.send(data);
// });