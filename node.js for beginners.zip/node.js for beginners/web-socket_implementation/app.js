const express = require('express');
const app = express();

const server = app.listen(8000,function(){
    console.log('server was live now at http://127.0.0.1:8000');
});
//console.log('server was live now at http://127.0.0.1:8000');
app.use(express.static('public'));

const socket = require('socket.io');
var io = socket(server);

io.on('connection',function(socket){
    console.log('server connection open to establish   ' + socket.id);

    socket.on('click',function(data){
        io.sockets.emit('click',data);
    });

    socket.on("keypress",function(data){
        socket.broadcast.emit('keypress',data);
    });
   
    socket.on("videoplay",function(data){
        socket.broadcast.emit('videoplay',data);
    });
});

