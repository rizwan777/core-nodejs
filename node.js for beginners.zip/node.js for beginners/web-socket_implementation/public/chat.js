

//establish connection between app.js(server) and chat.js(client)
var socket = io.connect("http://127.0.0.1:8000");
console.log('connection established successfully');

//query for Dom 

var name        = document.getElementById('handle'),
    detail      = document.getElementById('message'),
    write       = document.getElementById('output'),
    check       = document.getElementById('send'),
    test        = document.getElementById('feedback'),
    vd          = document.getElementById('video');

//emitt the event

check.addEventListener('click',function(data){
    socket.emit('click',{
        name    :   handle.value,
        detail  :   message.value,
   
    });
});

detail.addEventListener("keypress",function(data){
    socket.emit("keypress",{name :handle.value});

});

vd.addEventListener("videoplay",function(data){
    socket.emit('videoplay', {vd: video.value});
})



//event write the code

socket.on('click',function(data){
    feedback.innerHTML = "";
    output.innerHTML += '<p><strong> ' + data.name +'  : '+ data.detail+'</strong></p>';
    message.innerHTML="";
});


socket.on('keypress',function(data){
    feedback.innerHTML = '<p>' + data.name  + '    is typing now....';
});

socket.on('videoplay',function(data){
    video.innerHTML = data.vd;

});

