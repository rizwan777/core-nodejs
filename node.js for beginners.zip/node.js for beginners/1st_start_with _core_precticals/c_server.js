var http = require("http");
http.createServer(function(request,response)
	{
		console.writeHeader(200,{'Content-Type' : 'text/plain'});
		console.end('Hello bond...!!');
	}).listen('8088');