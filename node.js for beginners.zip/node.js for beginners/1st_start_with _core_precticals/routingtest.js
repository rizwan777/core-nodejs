var express=require('express');
var data = express();

data.get('/home',function(req,res){
    res.send('hello world');
});
data.listen(3000);


var http =require('http');
http.createServer(function(req,res){
    res.writeHead(200,{'Content-Type':'text/plain'});
}).listen(4000);
console.log("Server was live http://127.0.0.1:4000");

data.get('/server',function(req,res){
        res.end('server was live now');
});

data.post('')
