function mainfunction(callback)
{
    var somedata ="bond of callback";
    callback(somedata);
    
}
mainfunction(function(a)
{
    console.log(a + '1st');
});

mainfunction(function (b)
{
    console.log(b + '2nd');
    tt(b);
   
});

function tt (d)
{
    console.log(d + '3rd');
}
   