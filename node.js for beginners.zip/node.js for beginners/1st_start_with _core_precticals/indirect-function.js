var http = require ("http");

var test = (services)=>{console.write(services);}

var services= http.createServer(function(request,response) 
    {
        response.writeHead(200,{'Content-Type':'type/plain'});
        response.end("Write by indirect Function");
    }
    
).listen(8088);
console.log('server started on http://127.0.0.1:8088');   