var fs = require('fs');
var file = 'input.txt';        // hear we import 'input.txt' to file variable

function exit(exists){
    if(exists)
        fs.stat(file,status);       // this function call 'status' function

}
function status(err,stat)
{
    if (err)
        throw err;
    if (stat.isFile())
        fs.readFile(file,'utf8',readfilenow); // this function call 'readfilenow' function
}
function readfilenow(err, data){
    if(err)
        throw (err);
    if (data)
        console.log(data.toString()); //this write the text file to console.
}
fs.exists(file,exit); // this function is the starting point of the exicution
                     // 'exit' funciton call with 'exists' parameter