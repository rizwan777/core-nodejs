var fs = require("fs");
console.log('progrme started...!!');
fs.readFile('input.txt',function(err,data)
{
    if(err)
    {
      return  console.error(err);
    }
    console.log(data.toString());
}
);
console.log("programe ended..!");
