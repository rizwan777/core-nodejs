var express = require('express');
var URL_routing = express.Router();

URL_routing.get('/',function(req,res){
    res.sendFile(__dirname + '/index.html');
});

module.exports= URL_routing;
