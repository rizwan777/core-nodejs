var express = require('express');
var data = express();
var external_URL =require('./routes.js');
data.use('/app/model',external_URL);


data.use(function(req,res){
    res.send("data wil be added...!!");
}).listen(8080);

console.log("http://127.0.0.1:8080");

