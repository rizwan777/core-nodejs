const express = require("express");
const app = express();
const emp = [
    { id : 'E001', name: 'Bond', salary: 3000},
    { id : 'E002', name: 'James', salary: 4000},
    { id : 'E003', name: 'David', salary: 5000},
    { id : 'E004', name: 'Backham', salary: 7000},
    { id : 'E005', name: 'Jack', salary: 9000}
];
//routine of the url will be start by hear 

const port = process.env.PORT || 8000;
app.listen(port, ()=>(console.log(`Server will be conected on ${port}`)));
app.get('/',(req,res)=>
    {
        res.send('Welcome to try at one point');
    }
);
app.get('/api/employee',(req,res)=>
{
    res.send(emp);
});
app.get('/api/employee/?:id&:salary',(req,res)=>
{
    const d = req.query(parseInt(req.params.salary));
    const data =emp.find((a=>a.id === req.params.id) && (a.salary === d));
    if(!data) res.status(404).send('Employee ID not found Please Enter Proper One');
    res.send(data);

});