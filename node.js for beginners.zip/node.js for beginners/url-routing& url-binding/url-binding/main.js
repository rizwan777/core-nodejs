var express = require('express');
var data = express();
var another = require('/assets');

data.get('/',function (req,res){
    res.send("Enter the Name of State , City name ,and Home number as parameter ")
});
data.get('/:state',function(req,res){
    res.send("This route is for State" + req.params.state);
})
data.get('/:state/:city',function(req,res){
    res.send("this route is for state  "+ req.params.state + ' name of city was   '+ req.params.city);
});
data.get('/:state/:city/:id([0-9]{3})',function(req,res){
    res.send("this route is for state  "+ req.params.state + ' name of city was   '+ req.params.city + '  Home Number is  ' + req.params.id);
});
data.listen(4000);
console.log("Server is live at http://localhost:4000");
