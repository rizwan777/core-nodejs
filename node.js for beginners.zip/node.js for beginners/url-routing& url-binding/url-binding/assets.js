//import express to handle url routing

var express = require('express');
var rout = express.Router();

// get and post method was declared below
rout.get('/',function(req,res){
    res.send("first function called by GET Method.")
});

rout.get('/',function(req,res){
    res.send("Second function called by GET Method.")
});

rout.get('/',function(req,res){
    res.send("Second-One function called by GET Method.")
});
rout.get('*',function(req,res){
    res.send("Sorry, this is an invalid URL...")
});
rout.get('/take',function(req,res){
    res.send("test for take to times get method function called by GET Method.")
});

// specified with '/home' rout to clear understanding of routing
rout.get('/home',function(req,res,next){
    res.send("Third function called by GET Method with specific attached path '/home'.")
    next();
});

//post method also you can check it by terminal and used command ==>'curl -X POST "http://localhost:{PORT}"'
rout.post('/',function(req,res){
    
    res.status(200).send("post method status with content check..!!check the status to verify 200 ..!!");
});
// we using the export to access this function with other file in our case{main.js}

module.exports= rout;