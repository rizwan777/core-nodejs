
var express = require('express');
var app = express();

var access = require('./assets.js');

app.use('/app/routes',access);
app.use(function(req,res,next){
    console.log("A new request received at "+ Date.now());
    
});
app.listen(8088);

console.log('server was running on http://127.0.0.1:8088');







    